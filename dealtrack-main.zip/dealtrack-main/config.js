var config = {
  MSSQL: {
    StocksConnectionString: {
      user: "application-api",
      password: "asdf",
      server: "spactrack.cimxxtvyqfvq.us-east-1.rds.amazonaws.com",
      database: "Stocks.Dev",
    },
    region: "us-east-1",
  },
  DynamoDB: {
    AWSConfiguration: {
      credentials: {
        accessKeyId: "asdf",
        secretAccessKey: "asdf",
      },
      region: "us-east-1",
      prefix: "dev",
      dax: {
        enabled: false,
        endpoints: [
          "daxs://prod-cluster.xxoksw.dax-clusters.us-east-1.amazonaws.com",
        ],
      },
    },
  },
  APIs: {
    FinnhubAPI: {
      // key: 'c3qqh82ad3i98m4i9aig'
      key: 'c7eb9oiad3ifpe0p8sg0'
    }
  },
  Logging: {
    LogLevel: {
      Default: "Warning",
    },
  },
  AllowedHosts: "*",
};

module.exports = config;
