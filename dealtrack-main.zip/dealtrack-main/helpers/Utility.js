class Utility {

    static ChunkInGroups(arr, size) {
        var myArray = [];

        for (var i = 0; i < arr.length; i += size) {

            myArray.push(arr.slice(i, i + size));
        }
        return myArray;
    }

    async getAllUrls(urls) {
        try {
            var data = await Promise.all(
                urls.map(
                    url =>
                        fetch(url).then(
                            (response) => response.json()
                        )));

            return (data)

        } catch (error) {
            console.log(error)

            throw (error)
        }
    }

    static DataTableEditorToJSON(input) {
        var json = {};

        var props = Object.keys(input);
        var symbolExtract = false;

        props.forEach(prop => {

            var regx = /data\[([\w-\d]+)\]\[([\w-\d]+)\]/gi;
            var match = regx.exec(prop);

            if (match) {
                var value = input[`${prop}`];

                if (match[2] == "companyId") {
                    value = parseInt(input[`${prop}`]);
                }

                json[`${match[2]}`] = value;
            }

        });

        return json;
    }

    static UserFromPostRequest(body) {
        var user = {
            id : body.id,
            membership : body.membership,
            email : body.email
        };

        return user;
    }

    static ProductFromPostRequest(body) {
        var product = {
            name : body.name,
            settings : body.settings,
        };

        return product;
    }
}

module.exports = Utility;