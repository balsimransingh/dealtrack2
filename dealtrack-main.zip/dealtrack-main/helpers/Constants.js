class Constants {
    static VersionZero = 'ver_0';
    static Zero = '0';

}

module.exports = Constants;