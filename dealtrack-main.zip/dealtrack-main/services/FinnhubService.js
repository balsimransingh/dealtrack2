const finnhub = require("finnhub");
const config = require("../config");
//require("dotenv").config({ path: ".env" });
const dataService = require("./DataService");
const moment = require("moment");

class FinnhubService {
  constructor() {
    this.api_key = finnhub.ApiClient.instance.authentications["api_key"];
    this.api_key.apiKey = config.APIs.FinnhubAPI.key; // Replace this
    this.finnhubClient = new finnhub.DefaultApi();
    this.sqlService = new dataService();
  }

  async runFinnhubService(){

    // GetSQL, OUTPUT quotes ----------------
    var pulledSQLdata = await this.GetSQL().then(query => {
      return query
    });
    pulledSQLdata = pulledSQLdata[0]
    // console.log(pulledSQLdata)

    // get max(stockID) from sql, and use that in the for loop below for stockId
    var stock_Id = await this.GetStockId().then(query => {
      return query
    });

    // InsertSQLdata(symbol, companyID) -------------------
    // We could also add the UpdateStock method in this map method to update each stock as we add them
    // the first time around. ------------------
    for (let tableRow of pulledSQLdata) {  
      var symbol = tableRow.CompletedCommonSymbol ?? tableRow.CommonSymbol;
      var dataRow = await this.GetFinnhubData(symbol).then(output => {
        return output
      });
      dataRow["timeStamp"] = moment().format("YYYY-MM-DD HH:mm:ss");
      dataRow["companyId"] = tableRow['CompanyId'];
      dataRow["stockId"] = stock_Id;
      this.InsertSQLdata(dataRow)
      stock_Id++;
    }
    // console.log("The stocks have been inserted\n");

    return "Finnhub Service Completed"

    // GetFinnhubdata INPUT: quotes["Symbol"] -- OUTPUT finnhub api results --------------
    // build a list of objects of SQL update column data from the finnhub api results ------
    // const FinnhubSQLdata = []
    // var dataRow
    // for (let tableRow of pulledSQLdata) {
    //   dataRow = await this.GetFinnhubData(tableRow["Symbol"]).then(output => {
    //     return output
    //   });
    //   FinnhubSQLdata.push(dataRow)
    //   // console.log(`Stock is ${tableRow["Symbol"]} and data is ${JSON.stringify(dataRow)}`)
      
    //   // // UpdateSQLdata .. create a UpdateFinnhubSQLstock
    //   this.UpdateFinnhubSQLstock(dataRow)
    // }
    // console.log("Finnhubsql updata data received...\n")
    // console.log(FinnhubSQLdata)

  }

  async InsertSQLdata(row_obj){
    return new Promise((resolve, reject) => {
      this.sqlService.InsertSQLQuery(row_obj).then((results) => {
        if (results) {
          resolve(results);
          // console.log("The stock has been inserted");
        } else {
          reject(null);
        }
      });
    });
  }

  async UpdateFinnhubSQLstock(updatedStockQuote) {
    return new Promise((resolve, reject) => {
      this.sqlService.UpdateSQLQuery(updatedStockQuote).then((results) => {
        if (results) {
          resolve(results);
          // console.log(`The stock: ${updatedStockQuote["symbol"]} has been updated`);
        } else {
          reject(null);
        }
      });
    });
  }

  async GetFinnhubData(symbol) {
    var apiData
    apiData = await this.GetQuote(symbol).then((results) => {
      return results
    });
    const sqlObject = {
                  "symbol": symbol,
                  "open": apiData['o'],
                  "high": apiData['h'],
                  "low": apiData['l'],
                  "close": apiData['c'],
                  "prevClose": apiData['pc'],
                  "difference": apiData['d'],
                  "differencePct": apiData['dp']
                }
    return sqlObject
  }

  async GetQuote(symbol) {
    return new Promise((resolve, reject) => {
      // console.log(`Data for stock: ${symbol}`)
      this.finnhubClient.quote(
        symbol.toUpperCase(),
        (error, data, response) => {
          if (data) {
            resolve(data);
            //  console.log(data)
          } else {
            reject(response);
          }
        }
      );
    });
  }

  async GetSQL() {
    return new Promise((resolve, reject) => {
      this.sqlService.GetCompanySymbols().then((results) => {
        if (results) {
          console.log("The query has been reached");
          resolve(results);
        } else {
          reject(null);
        }
      });
    });
  }

  async GetStockId() {
    return new Promise((resolve, reject) => {
      this.sqlService.GetMaxStockId().then((results) => {
        if (results) {
          // console.log("The query has been reached");
          resolve(results);
        } else {
          reject(null);
        }
      });
    });
  }

  
}

module.exports = FinnhubService;
