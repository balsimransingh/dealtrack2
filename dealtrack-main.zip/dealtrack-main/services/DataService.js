const DynamoContext = require("../datalayer/context/DynamoContext");
const SqlContext = require("../datalayer/context/SqlContext");
const DataRepository = require('../datalayer/repositories/DataRepository');


class DataService {

    constructor(){
        
        this.SqlContext = new SqlContext();
        this.DynamoContext = new DynamoContext();
        this.DataRepository = new DataRepository();
    }

    async SQLQuery() {
      try {
        var queryResult = await this.SqlContext.Sequelize.query(`SELECT TOP 100 [StockId]
        ,[CompanyId]
        ,[Symbol]
        ,[SecurityTypeId]
        ,[LatestPrice]
        ,[LatestVolume]
        ,[PreviousVolume]
        ,[ExtendedPrice]
        ,[ChangePercent]
        ,[Week52High]
        ,[Week52Low]
        ,[MarketCap]
        ,[CreatedAt]
        ,[CreatedByUserId]
        ,[UpdatedAt]
        ,[LastUpdatedByUserId]
        ,[AvgTotalVolume]
        ,[Change]
        ,[Close]
        ,[IsUSMarketOpen]
        ,[Open]
        ,[PreviousClose]
        ,[YtdChange]
        ,[EntryId]
        ,[ExtendedPriceChangePercent]
        ,[OutstandingShares]
        ,[LatestUpdate]
        ,[ExtendedPriceTime]
        ,[DelayedPrice]
        ,[DelayedPriceTime]
        ,[ExtendedChange]
        ,[High]
        ,[HighTime]
        ,[Low]
        ,[LowTime]
    FROM [Stocks.Dev].[dbo].[Stock]`);
        //   const queryResult = await mssql.query(`SELECT * from stocks.dev LIMIT 5`);
        // console.log("queryResult");
        // console.log(queryResult);
        return queryResult;
    
      } catch (err) {
        console.log("**ERROR**: ", err);
        return null;
      }
    
    }

    async GetCompanySymbols() {
      try {
        var queryResult = await this.SqlContext.Sequelize.query(`SELECT TOP 100 [CompanyId]
        ,[CompanyName]
        ,[CommonSymbol]
        ,[WarrantSymbol]
        ,[UnitSymbol]
        ,[CreatedAt]
        ,[CreatedByUserId]
        ,[UpdatedAt]
        ,[LastUpdatedByUserId]
        ,[CompanyStatusId]
        ,[CompletedCommonSymbol]
        ,[CompletedWarrantSymbol]
        ,[Disabled]
        ,[EntryId]
    FROM [Stocks.Dev].[dbo].[Company]`);
        // console.log(queryResult);
        return queryResult;
    
      } catch (err) {
        console.log("**ERROR**: ", err);
        return null;
      }
    }

    async GetMaxStockId() {
      try {
        var queryResult = await this.SqlContext.Sequelize.query(`SELECT MAX(stockId) as max_stockId
        FROM [Stocks.Dev].[dbo].[Finnhub];`);
        // console.log(queryResult);
        return queryResult[0][0].max_stockId == null ? 1 : queryResult[0][0].max_stockId + 1;
    
      } catch (err) {
        console.log("**ERROR**: ", err);
        return null;
      }
    }

    async InsertSQLQuery(stock_obj) {
      try {
        var queryResult = await this.SqlContext.Sequelize.query(`INSERT INTO [Stocks.Dev].[dbo].[Finnhub] 
        VALUES ('${stock_obj.symbol}',
        ${stock_obj.companyId}, 
        ${stock_obj.stockId},
        '${stock_obj.timeStamp}', 
        ${stock_obj.open}, 
        ${stock_obj.high}, 
        ${stock_obj.low}, 
        ${stock_obj.close}, 
        ${stock_obj.prevClose}, 
        ${stock_obj.difference},
        ${stock_obj.differencePct});`);
        // console.log(queryResult);
        return queryResult;
    
      } catch (err) {
        console.log("**ERROR**: ", err);
        return null;
      }
    }

    async UpdateSQLQuery(stockQuote) {
      try {
        var queryResult = await this.SqlContext.Sequelize.query(`UPDATE [Stocks.Dev].[dbo].[Finnhub] 
        SET [open] = ${stockQuote["open"]},
            [high] = ${stockQuote["high"]},
            [low] = ${stockQuote["low"]},
            [close] = ${stockQuote["close"]},
            [prevClose] = ${stockQuote["prevClose"]},
            [difference] = ${stockQuote["difference"]},
            [differencePercent] = ${stockQuote["differencePercent"]}
        WHERE [symbol] = '${stockQuote["symbol"]}'`);
        // console.log(queryResult);
        return queryResult;
    
      } catch (err) {
        console.log("**ERROR**: ", err);
        return null;
      }
    }

    async DynamoQuery(){

        var tableName = DynamoContext.GetTableName('stock');

        var params = {
            TableName: tableName               
        }
        var queryResult = this.DataRepository.Scan(params);

        return queryResult;


    }
    async MasterData(){

      //Get latest sql data of all companies
      var stockInfo = await this.DataRepository.GetStockDetails();
      //still need to get stock data in query
      //get dynamo data of all companies
      var savedDynamoDetails = await this.DataRepository.GetStockMarketDetailsInfo(stockInfo);
      
      var result = stockInfo.filter(s => savedDynamoDetails.some(d => d.companyId === s.CompanyId)).map(s => {


        var details = savedDynamoDetails.find(d => d.companyId == s.CompanyId);

        return{
          companyId:s.CompanyId,
          symbol:s.Symbol,
          stock: {
            latestPrice: s.CommonLatestPrice,
            percentChange: s.CommonChangePercent,
            dollarChange: s.CommonChange,
            volume: s.CommonLatestVolume,
            marketCap: s.CommonMarketCap
            
          },

          details:details
        }
        

      });
           //map sql to dynamo using map function on company 
      return result;
    }

    
    async Tiles(ids){
      //Get latest sql data of all companies
      var stockInfo = await this.DataRepository.GetStockDetails(ids);
      //still need to get stock data in query
      //get dynamo data of all companies
      var savedDynamoDetails = await this.DataRepository.GetStockMarketDetailsInfo(stockInfo);

      // the outter brackets are replaced with parentheses
      var idList = ids.replace(/[{()}]/g, '').split(',');
      ids = `(${ids.slice(1,-1)})`
      
      //console.log(`The ids are: \n${ids}`);

      var graphResult = await this.DataRepository.GetGraphData(ids);
    
      //var output = result.map(d => d.CompanyId);
      var output = graphResult.reduce(function (r, a) {
        r[a.CompanyId] = r[a.CompanyId] || [];
        r[a.CompanyId].push(a);
        return r;
      }, Object.create(null));
            
      var result = stockInfo.filter(s => savedDynamoDetails.some(d => d.companyId === s.CompanyId)).map(s => {


        var details = savedDynamoDetails.find(d => d.companyId == s.CompanyId);
        var priceHistory = output[s.CompanyId] ?? null;

        // logic to determine the dealine date for the company
        const deadline_date = new Date(details.ipoDate);
        const daysToAdd = details.completionMonths * 30;
        deadline_date.setDate(deadline_date.getDate() + daysToAdd);

        // some stocks do not have filingDate nor completions months which will prevent deadline_date cacls
        // used try catch to set these to undefined and prevent errors. 
        try {var startDate =  (details.filingDate).split(" ")[0];} catch {var startDate = undefined }
        try {var deadlineDate = String(deadline_date.toISOString());} catch {var deadlineDate = undefined }

        return{
          companyId:s.CompanyId,
          symbol:s.Symbol,
          tickerInfo: { //used for tiles
            companyName: details.companyName,
            ticker: s.Symbol,
            change: parseFloat((s.CommonChangePercent*100).toFixed(3)), //round to 3 decs
            currentPrice: s.CommonLatestPrice,
            exchange: details.exchange
          },
          progress: { //used for tiles
             startDate: startDate,
             deadlineDate: deadlineDate,
             marketCap: s.CommonMarketCap,
             marketTrustValue: parseFloat((s.CommonMarketCap/parseInt(details.trustValue)).toFixed(3))
          },
          stock: {
            latestPrice: s.CommonLatestPrice,
            percentChange: s.CommonChangePercent,
            dollarChange: s.CommonChange,
            volume: s.CommonLatestVolume,
            marketCap: s.CommonMarketCap
          },
          detailsTableInfo: details, // some of the entries used for the details table info in tiles
          priceHistory:{ // used in the tiles
            month: priceHistory.slice(0,60),
            sixMonths: priceHistory.slice(0,360) ,
            year: priceHistory
          }
        }

      });


      return result;

    };

}

module.exports = DataService;
