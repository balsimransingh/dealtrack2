var express = require("express");
var router = express.Router();

const FinnhubService = require("../services/FinnhubService");
const service = new FinnhubService();

router.get("/", function (req, res, next) {
  res.json("API, testing finnhub data capture");

});

router.get("/quote/:symbol", function (req, res) {
  var symbol = null;

  if (req.params.symbol) {
    symbol = req.params.symbol;
  }

  service.GetQuote(symbol).then((results) => {
    console.log("run finnhub process");
    res.json(results);
  });
});

router.get('/sql', function(req, res) {
  service.runFinnhubService().then(results => {
    // console.log("The output from the runFinnhubservice")
    console.log(results)
    res.json(results)
  }).catch((err) => console.log("Error occured", err))
});


module.exports = router;
