var express = require('express');
var router = express.Router();

const DataService = require("../services/DataService");
const service = new DataService();


router.get('/', function(req, res, next) {

    res.json('API, testing data transfer');    

  });

router.get("/mysqlQuery", function(req, res) {
  
    service.SQLQuery().then(results => {
      
     // console.log("run sql query");
      res.json(results);
    })
  
  });

router.get("/dynamoQuery", function(req,res){
    
    service.DynamoQuery().then(results => {

      console.log("run dynamo query");
      res.json(results);

    })

  });


router.get("/MasterData", function(req,res){
  
    service.MasterData().then(results => {

      res.json(results);

    })


});

router.get("/tiles/:ids", function(req,res){
  
  var ids = req.params.ids ?? null;

  service.Tiles(ids).then(results => {

    res.json(results);

  })


});


router.get("/Highlights", function(req,res){
  
  service.GetHighlights().then(results => {

    res.json(results);

  })


});




module.exports = router;