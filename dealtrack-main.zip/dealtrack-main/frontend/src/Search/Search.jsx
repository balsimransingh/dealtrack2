import { React, useState } from "react";
import TextField from "@mui/material/TextField";
// import List from "./Components/List";
import "../App.css";
// import MasterData from "../staticFiles/masterData.json";
import Button from "@mui/material/Button";
import { StyledEngineProvider } from "@mui/material/styles";
import StockTileBehaviour from "../StockTile/StockTileBehaviour";
import axios from "axios";
import SearchIcon from "@mui/icons-material/Search";
// import { useAsync } from "react-async";
// import { useFetch } from "react-async";

// export const List = (props) => {
//       const [stockData, setStockData] = useState("");
//   const filteredData = props.masterData.filter((stock) => {
//     if (props.input === "") {
//       return stock;
//     } else if (stock.symbol.toLowerCase().includes(props.input)) {
//       return stock;
//     } else if (stock.details.companyName.toLowerCase().includes(props.input)) {
//       return stock;
//     }
//   });
//   return (
//     <ul>
//       {filteredData.map((stock, index) => {
//         return (
//           <Button
//             onClick={(e) => {
//                 inputText = stock
//             }}
//             >
//               {stock.symbol} - {stock.details.companyName}
//           </Button>
//         );
//       })}
//     </ul>
//   );
// };

export const Search = (props) => {
  const [inputText, setInputText] = useState("");
  const [stockData, setStockData] = useState({});
  const [openStockData, setOpenStockData] = useState({});
  //   const [companyId, setCompanyId] = useState(0);

  //   useEffect(() => {
  //     const getStockResults = async () => {
  //       const results = await axios.get(
  //         "http://localhost:8080/api/tiles/" + "(" + { companyId } + ")"
  //       );
  //       setOpenStockData(results.data);
  //     };
  //     getStockResults();
  //   }, [companyId]);

  async function openStock() {
    var baseUrl = "http://localhost:8080";
    let url = `${baseUrl}/api/tiles/(${stockData.companyId})`;
    const results = await axios.get(url);
    console.log(results.data[0]);
    setOpenStockData(results.data[0]);
    // return results;
    //     setCompanyId(stockData.companyId);
    // return (
    //   <StyledEngineProvider injectFirst>
    //     <StockTileBehaviour stockData={openStockData} />
    //   </StyledEngineProvider>
    // );
    //     // setStockData(stock);
  }

  return (
    <div className="main">
      <div className="search">
        <TextField
          id="outlined-basic"
          onChange={(event) => setInputText(event.target.value)}
          variant="outlined"
          label="Search"
          value={inputText}
        />
      </div>

      <Button onClick={() => openStock()}>
        <SearchIcon></SearchIcon>
      </Button>
      {props.masterData
        .filter((stock) => {
          if (inputText === "") {
            return stock;
          } else if (
            stock.symbol.toLowerCase().includes(inputText.toLowerCase())
          ) {
            return stock;
          } else if (
            stock.details.companyName
              .toLowerCase()
              .includes(inputText.toLowerCase())
          ) {
            return stock;
          }
          // else if (
          //   stock.details.leadership
          //     .toLowerCase()
          //     .includes(inputText.toLowerCase())
          // ) {
          //   return stock;
          // }
        })
        .map((stock, index) => (
          <div className="box" key={index}>
            <Button
              onClick={(e) => {
                setInputText(stock.symbol);
                setStockData(stock);
              }}
            >
              {stock.symbol} - {stock.details.companyName} - {stock.companyId}
            </Button>
          </div>
        ))}
      {Object.keys(openStockData).length !== 0 && (
        <StockTileBehaviour stockData={openStockData} />
      )}
    </div>
  );
};

export default Search;
