import React from 'react';
import Masonry from './Components/Masonry';
import Grid from '@mui/material/Grid';  
import { StyledEngineProvider } from "@mui/material/styles";
import StockTileBehaviour from "../StockTile/StockTileBehaviour";
//import StockTile from '..StockTile';

// const Home = () => {
function Home ()
{

  //axios call here - api/tiles/:ids API call from dataController.
  //pass that data as props to the function StockTileBehaviour\
  //basically stockdata 

  let stockData = {
    tickerInfo: {
      companyName: "Apple",
      ticker: "AAPL",
      change: "+0.56%",
      currentPrice: "$150.45",
      exchange: "NYSE"
    },
    priceHistory: {
      month: [
        {
          date: "2022-03-01",
          price: 4000
        },
        {
          date: "2022-03-02",
          price: 3000
        },
        {
          date: "2022-03-03",
          price: 2000
        },
        {
          date: "2022-03-04",
          price: 2780
        },
        {
          date: "2022-03-05",
          price: 1890
        },
        {
          date: "2022-03-06",
          price: 2390
        },
        {
          date: "2022-03-07",
          price: 3490
        }
      ],
      sixMonths: [
        {
          date: "2022-03-01",
          price: 4000
        },
        {
          date: "2022-03-02",
          price: 3000
        },
        {
          date: "2022-03-03",
          price: 2000
        },
        {
          date: "2022-03-04",
          price: 2780
        },
        {
          date: "2022-03-05",
          price: 1890
        },
        {
          date: "2022-03-06",
          price: 2390
        },
        {
          date: "2022-03-07",
          price: 3490
        },
        {
          date: "2022-03-01",
          price: 4000
        },
        {
          date: "2022-03-02",
          price: 3000
        },
        {
          date: "2022-03-03",
          price: 2000
        },
        {
          date: "2022-03-04",
          price: 2780
        },
        {
          date: "2022-03-05",
          price: 1890
        },
        {
          date: "2022-03-06",
          price: 2390
        },
        {
          date: "2022-03-07",
          price: 3490
        },
        {
          date: "2022-03-01",
          price: 4000
        },
        {
          date: "2022-03-02",
          price: 3000
        },
        {
          date: "2022-03-03",
          price: 2000
        },
        {
          date: "2022-03-04",
          price: 2780
        },
        {
          date: "2022-03-05",
          price: 1890
        },
        {
          date: "2022-03-06",
          price: 2390
        },
        {
          date: "2022-03-07",
          price: 3490
        }
      ],
      year: [
        {
          date: "2022-03-01",
          price: 4000
        },
        {
          date: "2022-03-02",
          price: 3000
        },
        {
          date: "2022-03-03",
          price: 2000
        },
        {
          date: "2022-03-04",
          price: 2780
        },
        {
          date: "2022-03-05",
          price: 1890
        },
        {
          date: "2022-03-06",
          price: 2390
        },
        {
          date: "2022-03-07",
          price: 3490
        },
        {
          date: "2022-03-01",
          price: 4000
        },
        {
          date: "2022-03-02",
          price: 3000
        },
        {
          date: "2022-03-03",
          price: 2000
        },
        {
          date: "2022-03-04",
          price: 2780
        },
        {
          date: "2022-03-05",
          price: 1890
        },
        {
          date: "2022-03-06",
          price: 2390
        },
        {
          date: "2022-03-07",
          price: 3490
        },
        {
          date: "2022-03-01",
          price: 4000
        },
        {
          date: "2022-03-02",
          price: 3000
        },
        {
          date: "2022-03-03",
          price: 2000
        },
        {
          date: "2022-03-04",
          price: 2780
        },
        {
          date: "2022-03-05",
          price: 1890
        },
        {
          date: "2022-03-06",
          price: 2390
        },
        {
          date: "2022-03-07",
          price: 3490
        },
        {
          date: "2022-03-01",
          price: 4000
        },
        {
          date: "2022-03-02",
          price: 3000
        },
        {
          date: "2022-03-03",
          price: 2000
        },
        {
          date: "2022-03-04",
          price: 2780
        },
        {
          date: "2022-03-05",
          price: 1890
        },
        {
          date: "2022-03-06",
          price: 2390
        },
        {
          date: "2022-03-07",
          price: 3490
        },
        {
          date: "2022-03-01",
          price: 4000
        },
        {
          date: "2022-03-02",
          price: 3000
        },
        {
          date: "2022-03-03",
          price: 2000
        },
        {
          date: "2022-03-04",
          price: 2780
        },
        {
          date: "2022-03-05",
          price: 1890
        },
        {
          date: "2022-03-06",
          price: 2390
        },
        {
          date: "2022-03-07",
          price: 3490
        },
        {
          date: "2022-03-01",
          price: 4000
        },
        {
          date: "2022-03-02",
          price: 3000
        },
        {
          date: "2022-03-03",
          price: 2000
        },
        {
          date: "2022-03-04",
          price: 2780
        },
        {
          date: "2022-03-05",
          price: 1890
        },
        {
          date: "2022-03-06",
          price: 2390
        },
        {
          date: "2022-03-07",
          price: 3490
        }
      ]
    },
    progress: {
      startDate: "2022-03-10",
      deadlineDate: "2022-03-25",
      fundsTarget: 100000,
      fundsRaised: 50000
    },
    detailsTableInfo: {
      status: "Definitive Agreement",
      targetFocus: "Energy Transition, Sustainibility",
      targetCompany: "Bird Rides",
      trustValue: "$316,257,330",
      ipoDate: "2021-07-01",
      ipoSize: "$316.30",
      underwriters: "Goldman Sachs",
      leadership: "Scott McNeil (CEO, Switchbank I)"
    }
  };

  return (
    

    <Grid container direction={"row"}>
      <Grid item>
        <Masonry col = {2} title= "Technology"/>
      </Grid>
      <Grid item>
        <Masonry col = {3} title= "Finance"/>
      </Grid>
      <Grid item>
        <Masonry col = {2} title= "Health"/>
      </Grid>

      <StyledEngineProvider injectFirst>
        <StockTileBehaviour stockData={stockData} />
      </StyledEngineProvider>
    </Grid>
  );
};
  
export default Home;

