import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import Masonry from '@mui/lab/Masonry';
import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Typography,
} from '@mui/material';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import { styled } from '@mui/material/styles';
import * as React from 'react';

const heights = [150, 30, 90, 70, 90, 100, 150, 30, 50, 80];

const Item = styled(Paper)(({ theme }) => ({
  ...theme.typography.body2,
  color: theme.palette.text.secondary,
  border: '1px solid black',
}));

// 1. Creating the tile component
//     a. Figure out graph api 
//     b. temp test data (graph x/y values)
//        i. 1 set of graph data that has a positive trend, and one negative 
// 2. Integrate the component in masonry 
// 3. Dynamic Sizing with the market cap.
// 4. Create drawer, use same data as props from tile.  
// 5. Provide filter options for tree map 
// 6. Integrate search option 
// 7. 

export default function TreeMap(props) {
  return (
      <div>
        <Typography>{props.title}</Typography>
        <Box sx={{ width: 500, minHeight: 377 }}>
          <Masonry columns={props.col} spacing={1}>
            {heights.map((height, index) => (
              <Item key={index} sx={{ height }}>
                {index + 1}
              </Item>
              ))
            }
          </Masonry>
        </Box>
      </div>
   
  );
}
