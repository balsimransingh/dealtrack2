import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';



import { StyledEngineProvider } from "@mui/material/styles";
import StockTileBehaviour from "./StockTile/StockTileBehaviour";

ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById('root')
);

// Raw Data in JSON
// Master Data uses comapany ID as the identifier
let stockData = {
  tickerInfo: {
    companyName: "Apple",
    ticker: "AAPL",
    change: "+0.56%",
    currentPrice: "$150.45",
    exchange: "NYSE"
  },
  priceHistory: {
    month: [
      {
        date: "2022-03-01",
        price: 4000
      },
      {
        date: "2022-03-02",
        price: 3000
      },
      {
        date: "2022-03-03",
        price: 2000
      },
      {
        date: "2022-03-04",
        price: 2780
      },
      {
        date: "2022-03-05",
        price: 1890
      },
      {
        date: "2022-03-06",
        price: 2390
      },
      {
        date: "2022-03-07",
        price: 3490
      }
    ],
    sixMonths: [
      {
        date: "2022-03-01",
        price: 4000
      },
      {
        date: "2022-03-02",
        price: 3000
      },
      {
        date: "2022-03-03",
        price: 2000
      },
      {
        date: "2022-03-04",
        price: 2780
      },
      {
        date: "2022-03-05",
        price: 1890
      },
      {
        date: "2022-03-06",
        price: 2390
      },
      {
        date: "2022-03-07",
        price: 3490
      },
      {
        date: "2022-03-01",
        price: 4000
      },
      {
        date: "2022-03-02",
        price: 3000
      },
      {
        date: "2022-03-03",
        price: 2000
      },
      {
        date: "2022-03-04",
        price: 2780
      },
      {
        date: "2022-03-05",
        price: 1890
      },
      {
        date: "2022-03-06",
        price: 2390
      },
      {
        date: "2022-03-07",
        price: 3490
      },
      {
        date: "2022-03-01",
        price: 4000
      },
      {
        date: "2022-03-02",
        price: 3000
      },
      {
        date: "2022-03-03",
        price: 2000
      },
      {
        date: "2022-03-04",
        price: 2780
      },
      {
        date: "2022-03-05",
        price: 1890
      },
      {
        date: "2022-03-06",
        price: 2390
      },
      {
        date: "2022-03-07",
        price: 3490
      }
    ],
    year: [
      {
        date: "2022-03-01",
        price: 4000
      },
      {
        date: "2022-03-02",
        price: 3000
      },
      {
        date: "2022-03-03",
        price: 2000
      },
      {
        date: "2022-03-04",
        price: 2780
      },
      {
        date: "2022-03-05",
        price: 1890
      },
      {
        date: "2022-03-06",
        price: 2390
      },
      {
        date: "2022-03-07",
        price: 3490
      },
      {
        date: "2022-03-01",
        price: 4000
      },
      {
        date: "2022-03-02",
        price: 3000
      },
      {
        date: "2022-03-03",
        price: 2000
      },
      {
        date: "2022-03-04",
        price: 2780
      },
      {
        date: "2022-03-05",
        price: 1890
      },
      {
        date: "2022-03-06",
        price: 2390
      },
      {
        date: "2022-03-07",
        price: 3490
      },
      {
        date: "2022-03-01",
        price: 4000
      },
      {
        date: "2022-03-02",
        price: 3000
      },
      {
        date: "2022-03-03",
        price: 2000
      },
      {
        date: "2022-03-04",
        price: 2780
      },
      {
        date: "2022-03-05",
        price: 1890
      },
      {
        date: "2022-03-06",
        price: 2390
      },
      {
        date: "2022-03-07",
        price: 3490
      },
      {
        date: "2022-03-01",
        price: 4000
      },
      {
        date: "2022-03-02",
        price: 3000
      },
      {
        date: "2022-03-03",
        price: 2000
      },
      {
        date: "2022-03-04",
        price: 2780
      },
      {
        date: "2022-03-05",
        price: 1890
      },
      {
        date: "2022-03-06",
        price: 2390
      },
      {
        date: "2022-03-07",
        price: 3490
      },
      {
        date: "2022-03-01",
        price: 4000
      },
      {
        date: "2022-03-02",
        price: 3000
      },
      {
        date: "2022-03-03",
        price: 2000
      },
      {
        date: "2022-03-04",
        price: 2780
      },
      {
        date: "2022-03-05",
        price: 1890
      },
      {
        date: "2022-03-06",
        price: 2390
      },
      {
        date: "2022-03-07",
        price: 3490
      },
      {
        date: "2022-03-01",
        price: 4000
      },
      {
        date: "2022-03-02",
        price: 3000
      },
      {
        date: "2022-03-03",
        price: 2000
      },
      {
        date: "2022-03-04",
        price: 2780
      },
      {
        date: "2022-03-05",
        price: 1890
      },
      {
        date: "2022-03-06",
        price: 2390
      },
      {
        date: "2022-03-07",
        price: 3490
      }
    ]
  },
  progress: {
    startDate: "2022-03-10",
    deadlineDate: "2022-03-25",
    fundsTarget: 100000,
    fundsRaised: 50000
  },
  detailsTableInfo: {
    status: "Definitive Agreement",
    targetFocus: "Energy Transition, Sustainibility",
    targetCompany: "Bird Rides",
    trustValue: "$316,257,330",
    ipoDate: "2021-07-01",
    ipoSize: "$316.30",
    underwriters: "Goldman Sachs",
    leadership: "Scott McNeil (CEO, Switchbank I)"
  }
};
/*
ReactDOM.render(
  <StyledEngineProvider injectFirst>
    <StockTileBehaviour stockData={stockData} />
  </StyledEngineProvider>,
  document.querySelector("#root")
);
*/



// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
