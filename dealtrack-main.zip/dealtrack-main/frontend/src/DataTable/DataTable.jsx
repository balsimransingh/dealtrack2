import React, { createContext, useContext, useEffect, useState } from "react";
import axios from "axios";
import Button from "@mui/material/Button";

import { DataGrid, GridToolbar } from "@mui/x-data-grid";
import StockTileBehaviour from "../StockTile/StockTileBehaviour";
import { StyledEngineProvider } from "@mui/material/styles";
import Modal from "@mui/material/Modal";

export const DataTable = (props) => {
  const [openStockData, setOpenStockData] = useState({});
  const [open, setOpen] = React.useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

  const modalStyle = {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  };

  const [filterModel, setFilterModel] = React.useState({
    items: [
      {
        columnField: "latestPrice",
        operatorValue: ">",
        value: "10",
      },
    ],
  });

  const columns = [
    { field: "ticker", headerName: "TICKER", width: 90, type: "string" },
    {
      field: "companyName",
      headerName: "COMPANY NAME",
      width: 260,
      type: "string",
    },
    { field: "latestPrice", headerName: "LAST", width: 90, type: "number" },
    {
      field: "percentChange",
      headerName: "CHANGE %",
      width: 120,
      type: "number",
    },
    { field: "change", headerName: "CHANGE", width: 120, type: "number" },
    { field: "rating", headerName: "RATING", width: 120, type: "number" },
    { field: "volume", headerName: "VOLUME", width: 120, type: "number" },
    { field: "mktCap", headerName: "MKT CAP", width: 120, type: "number" },
  ];

  const tableData = props.masterData.map(function (stock) {
    return {
      id: stock.companyId,
      ticker: stock.symbol,
      companyName: stock.details.companyName,
      latestPrice: stock.stock.latestPrice,
      percentChange: stock.stock.percentChange,
      change: stock.stock.dollarChange,
      // rating: props.masterData.stock.rating,
      volume: stock.stock.volume,
      mktCap: stock.stock.marketCap,
    };
  });

  async function openStock(stock) {
    var baseUrl = "http://localhost:8080";
    let url = `${baseUrl}/api/tiles/(${stock.id})`;
    const results = await axios.get(url);
    setOpenStockData(results.data[0]);
    handleOpen();
  }

  return (
    <div style={{ height: 400, width: 1250 }}>
      <DataGrid
        rows={tableData}
        columns={columns}
        pageSize={10}
        rowsPerPageOptions={[10]}
        components={{ Toolbar: GridToolbar }}
        onCellDoubleClick={(e) => openStock(e)}
      />
      {Object.keys(openStockData).length !== 0 && (
        <Modal
          open={open}
          onClose={handleClose}
          aria-labelledby="modal-modal-title"
          aria-describedby="modal-modal-description"
          centered
          style={modalStyle}
        >
          <StockTileBehaviour stockData={openStockData} />
        </Modal>
      )}
    </div>
  );
};

export default DataTable;
