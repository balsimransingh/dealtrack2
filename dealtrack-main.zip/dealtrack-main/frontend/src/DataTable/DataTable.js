import * as React from "react";
import { DataGrid, GridToolbar } from "@mui/x-data-grid";

const columns = [
  { field: "ticker", headerName: "TICKER", width: 90 },
  { field: "name", headerName: "  NAME", width: 260 },
  { field: "last", headerName: "LAST", width: 60 },
  { field: "percentChange", headerName: "CHANGE %", width: 90 },
  { field: "change", headerName: "CHANGE", width: 90 },
  { field: "rating", headerName: "RATING", width: 120 },
  { field: "volume", headerName: "VOLUME", width: 100 },
  { field: "mktCap", headerName: "MKT CAP", width: 100 }
];

// Dummy Data
const tableData = [
  {
    id: 1,
    ticker: "AACQ",
    name: "ARTIUS ACQUISITION CORP.",
    last: "11.33",
    percentChange: "-3.98%",
    change: -0.47,
    rating: "Sell",
    volume: "3.379M",
    mktCap: "205.215M"
  },
  {
    id: 2,
    ticker: "AACQ",
    name: "ARTIUS ACQUISITION CORP.",
    last: "11.33",
    percentChange: "-3.98%",
    change: -0.47,
    rating: "Sell",
    volume: "3.379M",
    mktCap: "205.215M"
  },
  {
    id: 3,
    ticker: "AACQ",
    name: "ARTIUS ACQUISITION CORP.",
    last: "11.33",
    percentChange: "-3.98%",
    change: -0.47,
    rating: "Sell",
    volume: "3.379M",
    mktCap: "205.215M"
  },
  {
    id: 4,
    ticker: "AACQ",
    name: "ARTIUS ACQUISITION CORP.",
    last: "11.33",
    percentChange: "-3.98%",
    change: -0.47,
    rating: "Sell",
    volume: "3.379M",
    mktCap: "205.215M"
  },
  {
    id: 5,
    ticker: "AACQ",
    name: "ARTIUS ACQUISITION CORP.",
    last: "11.33",
    percentChange: "-3.98%",
    change: -0.47,
    rating: "Sell",
    volume: "3.379M",
    mktCap: "205.215M"
  }
];

export default function DataTable(props) {
  return (
    <div style={{ height: 400, width: "100%" }}>
      <DataGrid
        rows={tableData}
        columns={columns}
        pageSize={5}
        rowsPerPageOptions={[5]}
        components={{ Toolbar: GridToolbar }}
      />
    </div>
  );
}
