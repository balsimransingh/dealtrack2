import * as React from "react";
import Grid from "@mui/material/Grid";

export default function StockTickerInfo(props) {
  let changeStyle = { color: "green", fontSize: "20px" };
  let tickerInfoStyle = { fontWeight: "bold", fontSize: "25px" };

  return (
    <Grid
      container
      spacing={1}
      direction="row"
      justifyContent="space-around"
      alignItems="center"
    >
      <Grid item xs={4}>
        <div>
          <p style={tickerInfoStyle}>{props.tickerInfo.ticker}</p>
          <p>
            <small>
              {props.tickerInfo.exchange}: {props.tickerInfo.companyName}
            </small>
          </p>
        </div>
      </Grid>
      <Grid item xs={4}>
        <p style={changeStyle}>{props.tickerInfo.change}</p>
      </Grid>
      <Grid item xs={4}>
        <p style={tickerInfoStyle}>{props.tickerInfo.currentPrice}</p>
      </Grid>
    </Grid>
  );
}
