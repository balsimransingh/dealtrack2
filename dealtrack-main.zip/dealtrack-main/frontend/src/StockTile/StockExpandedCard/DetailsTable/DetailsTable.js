import * as React from "react";
import Stack from "@mui/material/Stack";
import Divider from "@mui/material/Divider";
import Grid from "@mui/material/Grid";
import DetailsTableEntry from "./DetailsTableEntry";

export default function DetailsTable(props) {
  return (
    <Grid
      container
      spacing={1}
      direction="row"
      justifyContent="space-between"
      alignItems="stretch"
    >
      <Grid item xs={6}>
        <Stack
          direction="column"
          divider={<Divider orientation="horizontal" flexItem />}
          justifyContent="space-evenly"
          alignItems="stretch"
          spacing={2}
        >
          <DetailsTableEntry
            label="Status"
            val={props.detailsTableInfo.status}
          />
          <DetailsTableEntry
            label="Target Focus"
            val={props.detailsTableInfo.targetFocus}
          />
          <DetailsTableEntry
            label="Target Company"
            val={props.detailsTableInfo.targetCompany}
          />
          <DetailsTableEntry
            label="Trust Value"
            val={props.detailsTableInfo.trustValue}
          />
        </Stack>
      </Grid>
      <Grid item xs={6}>
        <Stack
          direction="column"
          divider={<Divider orientation="horizontal" flexItem />}
          justifyContent="space-evenly"
          alignItems="stretch"
          spacing={2}
        >
          <DetailsTableEntry
            label="IPO Date"
            val={props.detailsTableInfo.ipoDate}
          />
          <DetailsTableEntry
            label="IPO Size (M)"
            val={props.detailsTableInfo.ipoSize}
          />
          <DetailsTableEntry
            label="Underwriters"
            val={props.detailsTableInfo.underwriters}
          />
          <DetailsTableEntry
            label="Leadership"
            val={props.detailsTableInfo.leadership}
          />
        </Stack>
      </Grid>
    </Grid>
  );
}
