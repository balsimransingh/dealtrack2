import * as React from "react";
import Stack from "@mui/material/Stack";
import Grid from "@mui/material/Grid";

export default function DetailsTableEntry(props) {
  return (
    <Stack>
      <Grid
        container
        spacing={2}
        direction="row"
        justifyContent="flex-start"
        alignItems="flex-start"
      >
        <Grid item xs={6}>
          <b> {props.label} </b>
        </Grid>
        <Grid item xs={6}>
          {props.val}
        </Grid>
      </Grid>
    </Stack>
  );
}
