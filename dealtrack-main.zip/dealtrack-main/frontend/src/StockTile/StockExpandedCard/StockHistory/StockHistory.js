import * as React from "react";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import Chart from "./Chart";

export default function StockHistory(props) {
  const [period, setPeriod] = React.useState("");

  const handleChange = (event) => {
    setPeriod(event.target.value);
  };

  return (
    <div>
      <FormControl sx={{ m: 1, minWidth: 80 }}>
        <InputLabel id="graph-dropdown-label">Period</InputLabel>
        <Select
          labelId="graph-dropdown-label"
          id="graph-dropdown"
          value={period}
          onChange={handleChange}
          autoWidth
          label="Period"
        >
          <MenuItem value="">
            <em>None</em>
          </MenuItem>
          <MenuItem value={props.priceHistory.month}>1 Month</MenuItem>
          <MenuItem value={props.priceHistory.sixMonths}>6 Months</MenuItem>
          <MenuItem value={props.priceHistory.year}>1 Year</MenuItem>
        </Select>
      </FormControl>

      <Chart data={period} />
    </div>
  );
}
