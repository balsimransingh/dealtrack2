import Grid from "@mui/material/Grid";
import CircularProgressWithLabel from "./CircularProgressWithLabel.js";

function daysLeftCalc(deadlineDate) {
  const oneDay = 24 * 60 * 60 * 1000; // hours*minutes*seconds*milliseconds
  const today = new Date();
  deadlineDate = Date.parse(deadlineDate);

  const diffDays = Math.round(Math.abs((deadlineDate - today) / oneDay));
  return diffDays;
}

function daysPercentageCalc(startDate, deadlineDate, daysLeft) {
  const oneDay = 24 * 60 * 60 * 1000; // hours*minutes*seconds*milliseconds

  startDate = Date.parse(startDate);
  deadlineDate = Date.parse(deadlineDate);
  const totalDays = Math.round(Math.abs((deadlineDate - startDate) / oneDay));
  var percentage = (daysLeft / totalDays) * 100;

  return percentage;
}

export default function ProgressVisual(props) {
  const daysLeft = daysLeftCalc(props.progress.deadlineDate);
  const timePercentage = daysPercentageCalc(
    props.progress.startDate,
    props.progress.deadlineDate,
    daysLeft
  );

  const fundsPercentage =
    (props.progress.fundsRaised / props.progress.fundsTarget) * 100;

  return (
    <Grid
      container
      spacing={1}
      direction="row"
      justifyContent="space-around"
      alignItems="center"
    >
      <Grid item xs={6}>
        <CircularProgressWithLabel
          progressValue={timePercentage}
          labelValue={`${daysLeft} days left`}
          color="error"
        />
      </Grid>
      <Grid item xs={6}>
        <CircularProgressWithLabel
          progressValue={fundsPercentage}
          labelValue={`$${props.progress.fundsRaised} raised`}
          color="success"
        />
      </Grid>
    </Grid>
  );
}
