import * as React from "react";
import Paper from "@mui/material/Paper";
import Stack from "@mui/material/Stack";
import { styled } from "@mui/material/styles";
import StockTickerInfo from "./TickerInfo/StockTickerInfo";
import StockHistory from "./StockHistory/StockHistory";
import ProgressVisual from "./ProgressVisual/ProgressVisual";
import DetailsTable from "./DetailsTable/DetailsTable";

const Item = styled(Paper)(({ theme }) => ({
  backgroundColor: theme.palette.mode === "dark" ? "#1A2027" : "#fff",
  ...theme.typography.body2,
  padding: theme.spacing(1),
  textAlign: "center",
  color: theme.palette.text.secondary
}));

export default function StockExpandedCard(props) {
  return (
    <Paper variant="elevation" elevation={15}>
      <Stack
        direction="column"
        justifyContent="space-evenly"
        alignItems="stretch"
        spacing={2}
      >
        <Item>
          <StockTickerInfo tickerInfo={props.tickerInfo} />
        </Item>
        <Item>
          <StockHistory priceHistory={props.priceHistory} />
        </Item>
        <Item>
          <ProgressVisual progress={props.progress} />
        </Item>
        <Item>
          <DetailsTable detailsTableInfo={props.detailsTableInfo} />
        </Item>
      </Stack>
    </Paper>
  );
}
