import * as React from "react";
import CardContent from "@mui/material/CardContent";
import Grid from "@mui/material/Grid";
import Typography from "@mui/material/Typography";
import StockHistoryChart from "./StockHistoryChart";

export default function StockBaseCard(props) {
  let changeStyle = { color: "green", fontSize: "16px" };

  return (
    <CardContent>
      <Grid
        container
        spacing={2}
        direction="row"
        justifyContent="space-around"
        alignItems="flex-start"
      >
        <Grid item xs={8}>
          <Typography gutterBottom variant="h5" component="div">
            {props.tickerInfo.ticker}
          </Typography>
        </Grid>
        <Grid item xs={4}>
          <p style={changeStyle}>{props.tickerInfo.change}</p>
        </Grid>
      </Grid>
      <Grid container spacing={2}>
        <Grid item xs={12}>
          <Typography gutterBottom variant="h5" component="div">
            {props.tickerInfo.currentPrice}
          </Typography>
        </Grid>
      </Grid>
      <Grid container spacing={2}>
        <Grid item xs={12}>
          <StockHistoryChart priceHistory={props.priceHistory} />
        </Grid>
      </Grid>
    </CardContent>
  );
}
