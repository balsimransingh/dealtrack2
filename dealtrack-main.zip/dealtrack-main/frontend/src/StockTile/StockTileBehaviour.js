import * as React from "react";
import Card from "@mui/material/Card";
import CardActionArea from "@mui/material/CardActionArea";
import Drawer from "@mui/material/Drawer";
import StockBaseCard from "./StockBaseCard/StockBaseCard";
import StockExpandedCard from "./StockExpandedCard/StockExpandedCard";

export default function StockTileBehaviour(props) {
  // Setting Up stuff for the drawer
  const [state, setState] = React.useState(false);

  const toggleDrawer = (open) => (event) => {
    setState(open);
  };
  // do additional formatting 
  

  return (
    <div>
      <Card sx={{ maxWidth: 345 }}>
        <CardActionArea onClick={toggleDrawer(true)}>
          <StockBaseCard
            tickerInfo={props.stockData.tickerInfo}
            priceHistory={props.stockData.priceHistory.month}
          />
        </CardActionArea>
      </Card>
      <Drawer anchor={"right"} open={state} onClose={toggleDrawer(false)}>
        <StockExpandedCard
          tickerInfo={props.stockData.tickerInfo}
          priceHistory={props.stockData.priceHistory}
          progress={props.stockData.progress}
          detailsTableInfo={props.stockData.detailsTableInfo}
        />
      </Drawer>
    </div>
  );
}
