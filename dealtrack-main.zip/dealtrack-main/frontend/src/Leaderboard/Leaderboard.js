import React from 'react';
  
// const Leaderboard( = () => ){
function Leaderboard()
{
  return (
    <div>
      <h1>This is the leaderboard page</h1>
    </div>
  );
};
  
export default Leaderboard;