import * as React from "react";
import Leaderboard from "./LeaderboardTiles";
import Card from "@mui/material/Card";
import { Typography } from "@mui/material";

export default function LeaderboardSection(props) {
  return (
    <Card elevation={6}>
      <Typography variant="h4" component="div" gutterBottom align="Center">
        title
      </Typography>
      <Leaderboard stockData={props.stockData} />
    </Card>
  );
}
