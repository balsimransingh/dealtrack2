import * as React from "react";
import StockTileBehaviour from "../../StockTile/StockTileBehaviour";

export default function LeaderboardData(props) {
  return (
    <div>
      <StockTileBehaviour stockData={props.stockData} />
      <StockTileBehaviour stockData={props.stockData} />
      <StockTileBehaviour stockData={props.stockData} />
      <StockTileBehaviour stockData={props.stockData} />
      <StockTileBehaviour stockData={props.stockData} />
      <StockTileBehaviour stockData={props.stockData} />
    </div>
  );
}
