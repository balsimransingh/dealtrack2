import React, { useEffect, useState } from "react";
import axios from "axios";

import LeaderboardSection from "./Pages/LeaderboardSection";
import Paper from "@mui/material/Paper";
import { Card, Grid, Typography } from "@mui/material";

export const Leaderboard = () => {
  const [dataResults, setDataResults] = useState({});

  var baseUrl = "http://localhost:8080";
  let url = `${baseUrl}/api/Highlights`;

  useEffect(() => {
    const getDataResults = async () => {
      const results = await axios.get(url);
      setDataResults(results.data);
    };
    getDataResults();
  }, []);

  //  <LeaderboardSection stockData={dataResults.gainers} />
  //<LeaderboardSection stockData={dataResults.losers} />
  // <LeaderboardSection stockData={dataResults.leaders} />

  //<LeaderboardSection stockData={stockData} />

  console.log(dataResults);

  // var stockData = {
  //   tickerInfo: {
  //     companyName: "Apple",
  //     ticker: "AAPL",
  //     change: "+0.56%",
  //     currentPrice: "$150.45",
  //     exchange: "NYSE",
  //   },
  //   priceHistory: {
  //     month: [
  //       {
  //         date: "2022-03-01",
  //         price: 4000,
  //       },
  //       {
  //         date: "2022-03-02",
  //         price: 3000,
  //       },
  //       {
  //         date: "2022-03-03",
  //         price: 2000,
  //       },
  //       {
  //         date: "2022-03-04",
  //         price: 2780,
  //       },
  //       {
  //         date: "2022-03-05",
  //         price: 1890,
  //       },
  //       {
  //         date: "2022-03-06",
  //         price: 2390,
  //       },
  //       {
  //         date: "2022-03-07",
  //         price: 3490,
  //       },
  //     ],
  //     sixMonths: [
  //       {
  //         date: "2022-03-01",
  //         price: 4000,
  //       },
  //       {
  //         date: "2022-03-02",
  //         price: 3000,
  //       },
  //       {
  //         date: "2022-03-03",
  //         price: 2000,
  //       },
  //       {
  //         date: "2022-03-04",
  //         price: 2780,
  //       },
  //       {
  //         date: "2022-03-05",
  //         price: 1890,
  //       },
  //       {
  //         date: "2022-03-06",
  //         price: 2390,
  //       },
  //       {
  //         date: "2022-03-07",
  //         price: 3490,
  //       },
  //       {
  //         date: "2022-03-01",
  //         price: 4000,
  //       },
  //       {
  //         date: "2022-03-02",
  //         price: 3000,
  //       },
  //       {
  //         date: "2022-03-03",
  //         price: 2000,
  //       },
  //       {
  //         date: "2022-03-04",
  //         price: 2780,
  //       },
  //       {
  //         date: "2022-03-05",
  //         price: 1890,
  //       },
  //       {
  //         date: "2022-03-06",
  //         price: 2390,
  //       },
  //       {
  //         date: "2022-03-07",
  //         price: 3490,
  //       },
  //       {
  //         date: "2022-03-01",
  //         price: 4000,
  //       },
  //       {
  //         date: "2022-03-02",
  //         price: 3000,
  //       },
  //       {
  //         date: "2022-03-03",
  //         price: 2000,
  //       },
  //       {
  //         date: "2022-03-04",
  //         price: 2780,
  //       },
  //       {
  //         date: "2022-03-05",
  //         price: 1890,
  //       },
  //       {
  //         date: "2022-03-06",
  //         price: 2390,
  //       },
  //       {
  //         date: "2022-03-07",
  //         price: 3490,
  //       },
  //     ],
  //     year: [
  //       {
  //         date: "2022-03-01",
  //         price: 4000,
  //       },
  //       {
  //         date: "2022-03-02",
  //         price: 3000,
  //       },
  //       {
  //         date: "2022-03-03",
  //         price: 2000,
  //       },
  //       {
  //         date: "2022-03-04",
  //         price: 2780,
  //       },
  //       {
  //         date: "2022-03-05",
  //         price: 1890,
  //       },
  //       {
  //         date: "2022-03-06",
  //         price: 2390,
  //       },
  //       {
  //         date: "2022-03-07",
  //         price: 3490,
  //       },
  //       {
  //         date: "2022-03-01",
  //         price: 4000,
  //       },
  //       {
  //         date: "2022-03-02",
  //         price: 3000,
  //       },
  //       {
  //         date: "2022-03-03",
  //         price: 2000,
  //       },
  //       {
  //         date: "2022-03-04",
  //         price: 2780,
  //       },
  //       {
  //         date: "2022-03-05",
  //         price: 1890,
  //       },
  //       {
  //         date: "2022-03-06",
  //         price: 2390,
  //       },
  //       {
  //         date: "2022-03-07",
  //         price: 3490,
  //       },
  //       {
  //         date: "2022-03-01",
  //         price: 4000,
  //       },
  //       {
  //         date: "2022-03-02",
  //         price: 3000,
  //       },
  //       {
  //         date: "2022-03-03",
  //         price: 2000,
  //       },
  //       {
  //         date: "2022-03-04",
  //         price: 2780,
  //       },
  //       {
  //         date: "2022-03-05",
  //         price: 1890,
  //       },
  //       {
  //         date: "2022-03-06",
  //         price: 2390,
  //       },
  //       {
  //         date: "2022-03-07",
  //         price: 3490,
  //       },
  //       {
  //         date: "2022-03-01",
  //         price: 4000,
  //       },
  //       {
  //         date: "2022-03-02",
  //         price: 3000,
  //       },
  //       {
  //         date: "2022-03-03",
  //         price: 2000,
  //       },
  //       {
  //         date: "2022-03-04",
  //         price: 2780,
  //       },
  //       {
  //         date: "2022-03-05",
  //         price: 1890,
  //       },
  //       {
  //         date: "2022-03-06",
  //         price: 2390,
  //       },
  //       {
  //         date: "2022-03-07",
  //         price: 3490,
  //       },
  //       {
  //         date: "2022-03-01",
  //         price: 4000,
  //       },
  //       {
  //         date: "2022-03-02",
  //         price: 3000,
  //       },
  //       {
  //         date: "2022-03-03",
  //         price: 2000,
  //       },
  //       {
  //         date: "2022-03-04",
  //         price: 2780,
  //       },
  //       {
  //         date: "2022-03-05",
  //         price: 1890,
  //       },
  //       {
  //         date: "2022-03-06",
  //         price: 2390,
  //       },
  //       {
  //         date: "2022-03-07",
  //         price: 3490,
  //       },
  //       {
  //         date: "2022-03-01",
  //         price: 4000,
  //       },
  //       {
  //         date: "2022-03-02",
  //         price: 3000,
  //       },
  //       {
  //         date: "2022-03-03",
  //         price: 2000,
  //       },
  //       {
  //         date: "2022-03-04",
  //         price: 2780,
  //       },
  //       {
  //         date: "2022-03-05",
  //         price: 1890,
  //       },
  //       {
  //         date: "2022-03-06",
  //         price: 2390,
  //       },
  //       {
  //         date: "2022-03-07",
  //         price: 3490,
  //       },
  //     ],
  //   },
  //   progress: {
  //     startDate: "2022-03-10",
  //     deadlineDate: "2022-03-25",
  //     fundsTarget: 100000,
  //     fundsRaised: 50000,
  //   },
  //   detailsTableInfo: {
  //     status: "Definitive Agreement",
  //     targetFocus: "Energy Transition, Sustainibility",
  //     targetCompany: "Bird Rides",
  //     trustValue: "$316,257,330",
  //     ipoDate: "2021-07-01",
  //     ipoSize: "$316.30",
  //     underwriters: "Goldman Sachs",
  //     leadership: "Scott McNeil (CEO, Switchbank I)",
  //   },
  // };

  return (
    <Paper elevation={12}>
      <Grid container direction="column">
        <Grid item>
          <Grid container>
            <Grid item>
              <Card>
                <Typography variant="h4" component="div" align="center">
                  Leaderboard
                </Typography>
              </Card>
            </Grid>
          </Grid>
        </Grid>
        <Grid item>
          <Grid container spacing={4} direction="row">
            <Grid item>
              <LeaderboardSection stockData={dataResults.gainers} />
            </Grid>
            <Grid item>
              <LeaderboardSection stockData={dataResults.losers} />
            </Grid>
            <Grid item>
              <LeaderboardSection stockData={dataResults.leaders} />
            </Grid>
          </Grid>
        </Grid>
      </Grid>
    </Paper>
  );
};

export default Leaderboard;
