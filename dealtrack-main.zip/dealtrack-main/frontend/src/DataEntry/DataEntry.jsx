import React, { createContext, useContext, useEffect, useState } from "react";
import axios from "axios";

export const DataEntry = () => {
    const [dataResults, setDataResults] = useState({});
    
};

// module.Exports = Home;
export default DataEntry;