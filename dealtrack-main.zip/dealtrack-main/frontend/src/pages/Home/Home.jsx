import React, { useEffect, useState } from "react";

import axios from "axios";

export const Home = () => {
  const [sqlResults, setSqlResults] = useState({});

  useEffect(() => {
    const getSqlResults = async () => {
      const results = await axios.get(
        "http://localhost:8080/finnhub/quote/aapl"
      );
      setSqlResults(results.data);
    };
    getSqlResults();
  }, []);

  return (
    <div>
      <h1>HOME PAGE</h1>
      {Object.keys(sqlResults).map((key) => {
        return (
          <p>
            {key} : {sqlResults[key]}
          </p>
        );
      })}
    </div>
  );
};

// module.Exports = Home;
export default Home;
