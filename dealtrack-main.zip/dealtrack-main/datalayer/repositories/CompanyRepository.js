const { Sequelize, Model, DataTypes, QueryTypes } = require('sequelize');

const SqlContext = require('../context/SqlContext');
const DynamoContext = require('../context/DynamoContext');
const Utility = require('../../helpers/Utility');

class CompanyRepository {
    constructor() {
        this.SqlContext = new SqlContext();
    }

    get Companies() {
        return this.SqlContext.Companies;
    }

}

module.exports = CompanyRepository;