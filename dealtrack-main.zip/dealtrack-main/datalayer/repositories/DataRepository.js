const { Sequelize, Model, DataTypes, QueryTypes } = require('sequelize');
const moment = require('moment');
const { query } = require('express');

const SqlContext = require('../context/SqlContext');
const DynamoContext = require('../context/DynamoContext');
const Utility = require('../../helpers/Utility');
const Constants = require('../../helpers/Constants');

const CompanyRepository = require('./CompanyRepository');

const Empty = '';
const YearStart = '2021-01-01';

class DataRepository {
    static Active = 1;
    static Inactive = 2;
    static BatchWriteMaximumCount = 25;

    constructor() {
        this.SqlContext = new SqlContext();
        this.DynamoContext = new DynamoContext();
        this.CompanyRepository = new CompanyRepository();
    }

    get Stocks() {
        return this.SqlContext.Stocks;
    }

    async QuoteArchive(date) {
        var queryResult = await this.SqlContext.Sequelize.query(
            `
            /* archive */
            INSERT INTO dbo.Stock_Archive
                SELECT	 [CompanyId]
                        ,[Symbol]
                        ,[SecurityTypeId]
                        ,[LatestPrice]
                        ,[LatestVolume]
                        ,[PreviousVolume]
                        ,[ExtendedPrice]
                        ,[ChangePercent]
                        ,[Week52High]
                        ,[Week52Low]
                        ,[MarketCap]
                        ,[CreatedAt]
                        ,[CreatedByUserId]
                        ,[UpdatedAt]
                        ,[LastUpdatedByUserId]
                        ,[AvgTotalVolume]
                        ,[Change]
                        ,[Close]
                        ,[IsUSMarketOpen]
                        ,[Open]
                        ,[PreviousClose]
                        ,[YtdChange]
                        ,[EntryId]
                        ,[ExtendedPriceChangePercent]
                        ,[OutstandingShares]
                        ,[LatestUpdate]
                        ,[ExtendedPriceTime]
                FROM dbo.Stock s WITH (NOLOCK)
                WHERE s.StockId not IN (
                    SELECT	StockId
                            --, *	
                    FROM dbo.Stock
                    WHERE CONVERT(VARCHAR(5), CreatedAt, 108) = '13:30' OR CONVERT(VARCHAR(5), CreatedAt, 108) = '20:00'
                )	
            
            
            /* delete */
            DELETE dbo.Stock
            WHERE StockId NOT IN (
                SELECT	StockId
                        --, *
                FROM dbo.Stock
                WHERE CONVERT(VARCHAR(5), CreatedAt, 108) = '13:30' OR CONVERT(VARCHAR(5), CreatedAt, 108) = '20:00'
            )
            `);

        return queryResult;
    }

    async GetStockMarketInfoEntryIds(statuses) {

        var queryResult = await this.SqlContext.Sequelize.query(
            `SELECT s.CompanyId, s.SecurityTypeId, MAX(s.EntryId) [LatestEntryId]
            FROM dbo.Stock s WITH (NOLOCK)
            JOIN dbo.Company c WITH (NOLOCK) ON s.CompanyId = c.CompanyId
            WHERE c.Disabled <> 1 AND c.CompanyStatusId IN (:status)
            GROUP by s.CompanyId, s.SecurityTypeId
            ORDER BY s.CompanyId, s.SecurityTypeId`,
            {
                replacements: { status: statuses },
                type: QueryTypes.SELECT
            });

        return queryResult;
    }

    async GetStockDetails(ids = null) {

        var includeIds = ids == null ? Empty : `AND c.CompanyId IN ${ids}`;

        var queryResult = await this.SqlContext.Sequelize.query(
            ` SELECT	c.CompanyId, ISNULL(c.CompletedCommonSymbol, c.CommonSymbol) [Symbol], c.CompanyName
            ,cs.EntryId [CommonEntryId], cs.LatestPrice [CommonLatestPrice], cs.ChangePercent [CommonChangePercent], cs.Change [CommonChange], cs.LatestVolume [CommonLatestVolume], cs.MarketCap [CommonMarketCap]
            
            FROM
            (   
                --current latest date
                SELECT pvt.CompanyId
                    ,[1] [CommonStockId]
                    ,cs.LatestPrice [CommonLatestPrice]
                FROM (
                    SELECT s.CompanyId, s.SecurityTypeId, MAX(StockId) [StockId]
                    FROM [dbo].[Stock]	s        
                    GROUP BY s.CompanyId, s.SecurityTypeId
                    --ORDER BY s.CompanyId
                ) AS src
                PIVOT
                (
                    max([StockId])
                    FOR SecurityTypeId IN ([1])
                ) AS pvt
                LEFT JOIN dbo.Stock cs ON cs.StockId = pvt.[1]
                --ORDER BY pvt.CompanyId
            ) curr
            JOIN dbo.Company c ON c.CompanyId = curr.CompanyId 
            LEFT JOIN dbo.Stock cs ON cs.StockId = curr.CommonStockId
            WHERE c.Disabled <> 1 AND cs.EntryId IS NOT NULL AND cs.LatestPrice IS NOT NULL AND cs.ChangePercent IS NOT NULL AND cs.Change IS NOT NULL AND cs.LatestVolume IS NOT NULL AND cs.MarketCap IS NOT NULL 
            ${includeIds}
            ORDER BY c.CompanyId   
`,
            {
                type: QueryTypes.SELECT
            });

        return queryResult;
    }


    
    async GetGraphData(ids) {
        try {
            var queryResult = await this.SqlContext.Sequelize.query(        
                `
                SELECT src.CompanyId
            ,cs.StockId [StockId]
            ,cs.LatestPrice [price]
            ,cs.UpdatedAt [date]
            ,cs.CreatedAt [CreatedAt]
                FROM (
                    SELECT rs.CompanyId,rs.EntryId,rs.StockId
                        FROM (
                            SELECT gs.CompanyId, gs.EntryId,gs.StockId, Rank() 
                                over (Partition BY gs.CompanyId
                                    ORDER BY gs.EntryId DESC ) AS Rank
                            FROM [dbo].[Stock]	gs  WITH (NOLOCK)
                            --company Ids
							WHERE gs.CompanyId in ${ids}
							
                    
                            ) rs WHERE Rank <= 150 --amount of entries per company
                ) AS src
                JOIN dbo.Stock cs ON cs.StockId = src.StockId 
				WHERE cs.EntryId IS NOT NULL AND cs.LatestPrice IS NOT NULL AND cs.ChangePercent IS NOT NULL AND cs.Change IS NOT NULL AND cs.LatestVolume IS NOT NULL AND cs.MarketCap IS NOT NULL
				ORDER BY [StockId] DESC
                `,{
                    plain: false,
                    raw: true,
                    type: QueryTypes.SELECT
                });

            return queryResult;
                                
        } catch (err) {
            console.log("**ERROR**: ", err);
            return null;
        }
    }
    

    
    async GetStockMarketInfoByCompanySymbol(symbol) {
        var queryResult = await this.SqlContext.Sequelize.query(
            `
            SELECT	c.CompanyId, c.CommonSymbol, c.CompanyName
            ,cs.EntryId [CommonEntryId], cs.LatestPrice [CommonLatestPrice], cs.ChangePercent [CommonChangePercent], cs.Change [CommonChange], cs.LatestVolume [CommonLatestVolume], cs.MarketCap [CommonMarketCap]
            ,ws.Symbol [WarrantSymbol], ws.EntryId [CommonEntryId], ws.LatestPrice [WarrantLatestPrice], ws.ChangePercent [WarrantChangePercent], ws.Change [WarrantChange], ws.LatestVolume [WarrantLatestVolume]
            ,us.Symbol [UnitSymbol], us.EntryId [CommonEntryId], us.LatestPrice [UnitLatestPrice], us.ChangePercent [UnitChangePercent], us.Change [UnitChange], us.LatestVolume [UnitLatestVolume]
            FROM
            (   
                --current latest date
                SELECT pvt.CompanyId
                    , [1] [CommonStockId], [2] [WarrantStockId], [3] [UnitStockId]
                    ,cs.LatestPrice [CommonLatestPrice], ws.LatestPrice [WarrantLatestPrice], us.LatestPrice [UnitLatestPrice]
                FROM (
                    SELECT s.CompanyId, s.SecurityTypeId, MAX(StockId) [StockId]
                    FROM [dbo].[Stock]	s        
                    GROUP BY s.CompanyId, s.SecurityTypeId
                    --ORDER BY s.CompanyId
                ) AS src
                PIVOT
                (
                    max([StockId])
                    FOR SecurityTypeId IN ([1], [2], [3])
                ) AS pvt
                LEFT JOIN dbo.Stock cs ON cs.StockId = pvt.[1]
                LEFT JOIN dbo.Stock ws ON ws.StockId = pvt.[2]
                LEFT JOIN dbo.Stock us ON us.StockId = pvt.[3]
                --ORDER BY pvt.CompanyId
            ) curr
            JOIN dbo.Company c ON c.CompanyId = curr.CompanyId 
            LEFT JOIN dbo.Stock cs ON cs.StockId = curr.CommonStockId
            LEFT JOIN dbo.Stock ws ON ws.StockId = curr.WarrantStockId
            LEFT JOIN dbo.Stock us ON us.StockId = curr.UnitStockId
            WHERE c.Disabled <> 1 AND c.CommonSymbol = :symbol or c.WarrantSymbol = :symbol or c.UnitSymbol = :symbol
            ORDER BY c.CommonSymbol    
            `, {
            replacements: {
                symbol: symbol
            },
            type: QueryTypes.SELECT
        });

        return queryResult
    }

    async GetStockMarketInfoByCompanyStatus(status, symbol) {

        var includeSymbol = symbol == null ? Empty : 'AND ISNULL(c.CompletedCommonSymbol, c.CommonSymbol) = :symbol';

        var queryResult = await this.SqlContext.Sequelize.query(
            `
			DECLARE @date DATETIME, @maxDate DATETIME
			SELECT @date = CAST(GETDATE() as date);			

			SELECT @maxDate = CAST(MAX(CreatedAt) as date) FROM [dbo].[Stock] s WITH (NOLOCK)

			IF (@date > @maxDate)
				SELECT @date = @maxdate			

            SELECT	c.CompanyId, c.CommonSymbol, c.CompletedCommonSymbol, c.CompanyName, c.CompanyStatusId
            ,cs.EntryId [CommonEntryId], cs.LatestPrice [CommonLatestPrice], cs.ChangePercent [CommonChangePercent], cs.Change [CommonChange], cs.LatestVolume [CommonLatestVolume], cs.MarketCap [CommonMarketCap], cs.ExtendedPrice [CommonExtendedPrice], cs.ExtendedPriceChangePercent [CommonExtendedChangePercent], cs.PreviousVolume [CommonPreviousDayVolume], cs.Week52High [CommonWeek52High], cs.Week52Low [CommonWeek52Low], cs.OutstandingShares [CommonOutstandingShares]
            ,ws.Symbol [WarrantSymbol], ws.EntryId [WarrantEntryId], ws.LatestPrice [WarrantLatestPrice], ws.ChangePercent [WarrantChangePercent], ws.Change [WarrantChange], ws.LatestVolume [WarrantLatestVolume], ws.ExtendedPrice [WarrantExtendedPrice], ws.ExtendedPriceChangePercent [WarrantExtendedChangePercent], ws.PreviousVolume [WarrantPreviousDayVolume], ws.Week52High [WarrantWeek52High], ws.Week52Low [WarrantWeek52Low]
            ,us.Symbol [UnitSymbol], us.EntryId [UnitEntryId], us.LatestPrice [UnitLatestPrice], us.ChangePercent [UnitChangePercent], us.Change [UnitChange], us.LatestVolume [UnitLatestVolume], us.ExtendedPrice [UnitExtendedPrice], us.ExtendedPriceChangePercent [UnitExtendedChangePercent], us.PreviousVolume [UnitPreviousDayVolume], us.Week52High [UnitWeek52High], us.Week52Low [UnitWeek52Low]            
            FROM
            (
                --current latest date
                SELECT pvt.CompanyId
                    , [1] [CommonStockId], [2] [WarrantStockId], [3] [UnitStockId]
                    ,cs.LatestPrice [CommonLatestPrice], ws.LatestPrice [WarrantLatestPrice], us.LatestPrice [UnitLatestPrice]
                FROM (
                    SELECT s.CompanyId, s.SecurityTypeId, MAX(StockId) [StockId]
                    FROM [dbo].[Stock] s WITH (NOLOCK)
					WHERE CAST(s.CreatedAt AS date) = @date					
                    GROUP BY s.CompanyId, s.SecurityTypeId
                    --ORDER BY s.CompanyId
                ) AS src
                PIVOT
                (
                    max([StockId])
                    FOR SecurityTypeId IN ([1], [2], [3])
                ) AS pvt
                LEFT JOIN dbo.Stock cs WITH (NOLOCK) ON cs.StockId = pvt.[1]
                LEFT JOIN dbo.Stock ws WITH (NOLOCK) ON ws.StockId = pvt.[2]
                LEFT JOIN dbo.Stock us WITH (NOLOCK) ON us.StockId = pvt.[3]
                --ORDER BY pvt.CompanyId
            ) curr
            JOIN dbo.Company c WITH (NOLOCK) ON c.CompanyId = curr.CompanyId
            LEFT JOIN dbo.Stock cs WITH (NOLOCK) ON cs.StockId = curr.CommonStockId
            LEFT JOIN dbo.Stock ws WITH (NOLOCK) ON ws.StockId = curr.WarrantStockId
            LEFT JOIN dbo.Stock us WITH (NOLOCK) ON us.StockId = curr.UnitStockId
            WHERE c.Disabled <> 1 AND c.CompanyStatusId IN(:status) 			
                    ${includeSymbol}
            ORDER BY ISNULL(c.CompletedCommonSymbol, c.CommonSymbol)
            `, {
            replacements: {
                status: status,
                symbol: symbol
            },
            type: QueryTypes.SELECT
        });

        return queryResult;
    }

    async GetStockDailyGainers() {
        var queryResult = await this.SqlContext.Sequelize.query(
            `    DECLARE @maxCreatedAt datetime, @maxUpdatedTime datetime, @dayDiff int, @minDate datetime, @maxExtendedPriceTime datetime

            SELECT	 @minDate = '1900-01-01'
                    ,@maxCreatedAt = MAX(CreatedAt)
                    ,@maxUpdatedTime = MAX(s.LatestUpdate)
                    ,@dayDiff = DATEDIFF(dd, MAX(s.LatestUpdate), MAX(CreatedAt))
            from dbo.Stock s

            SELECT @dayDiff = CASE WHEN @dayDiff < 0 THEN 0 ELSE @dayDiff END

			--SELECT @maxCreatedAt [maxCreatedAt], @maxUpdatedTime [maxUpdatedTime_LatestUpdate], @dayDiff [dayDiff], @maxExtendedPriceTime [maxExtendedPriceTime]

            SELECT TOP 10 pvt.CompanyId
            FROM (
                SELECT s.CompanyId, s.SecurityTypeId, MAX(StockId) [StockId]
                FROM [dbo].[Stock] s WITH (NOLOCK)
                WHERE CAST(s.CreatedAt AS date) = CAST(@maxUpdatedTime AS date)
                GROUP BY s.CompanyId, s.SecurityTypeId
                --ORDER BY s.CompanyId
            ) AS src
            PIVOT
            (
                max([StockId])
                FOR SecurityTypeId IN ([1], [2], [3])
            ) AS pvt
            JOIN dbo.Company c WITH (NOLOCK) ON c.CompanyId = pvt.CompanyId
            JOIN dbo.Stock cs WITH (NOLOCK) ON cs.StockId = pvt.[1]
            LEFT JOIN dbo.Stock ws WITH (NOLOCK) ON ws.StockId = pvt.[2]
            LEFT JOIN dbo.Stock us WITH (NOLOCK) ON us.StockId = pvt.[3]
            WHERE c.Disabled <> 1 AND cs.EntryId IS NOT NULL AND cs.LatestPrice IS NOT NULL AND cs.ChangePercent IS NOT NULL AND cs.Change IS NOT NULL AND cs.LatestVolume IS NOT NULL AND cs.MarketCap IS NOT NULL 
            --WHERE c.Disabled <> 1 AND c.CompanyStatusId IN (1) AND c.CompletedCommonSymbol IS NULL
			GROUP BY  pvt.CompanyId, cs.ChangePercent , cs.LatestVolume 

			ORDER BY
					cs.ChangePercent desc
					-- cs.ChangePercent asc
					-- cs.LatestVolume  desc
					
					
            `, { type: QueryTypes.SELECT });

        return queryResult;
    }

    async GetStockDailyLosers() {

        var queryResult = await this.SqlContext.Sequelize.query(
            `  DECLARE @maxCreatedAt datetime, @maxUpdatedTime datetime, @dayDiff int, @minDate datetime, @maxExtendedPriceTime datetime

            SELECT	 @minDate = '1900-01-01'
                    ,@maxCreatedAt = MAX(CreatedAt)
                    ,@maxUpdatedTime = MAX(s.LatestUpdate)
                    ,@dayDiff = DATEDIFF(dd, MAX(s.LatestUpdate), MAX(CreatedAt))
            from dbo.Stock s

            SELECT @dayDiff = CASE WHEN @dayDiff < 0 THEN 0 ELSE @dayDiff END

			--SELECT @maxCreatedAt [maxCreatedAt], @maxUpdatedTime [maxUpdatedTime_LatestUpdate], @dayDiff [dayDiff], @maxExtendedPriceTime [maxExtendedPriceTime]

            SELECT TOP 10 pvt.CompanyId
            FROM (
                SELECT s.CompanyId, s.SecurityTypeId, MAX(StockId) [StockId]
                FROM [dbo].[Stock] s WITH (NOLOCK)
                WHERE CAST(s.CreatedAt AS date) = CAST(@maxUpdatedTime AS date)
                GROUP BY s.CompanyId, s.SecurityTypeId
                --ORDER BY s.CompanyId
            ) AS src
            PIVOT
            (
                max([StockId])
                FOR SecurityTypeId IN ([1], [2], [3])
            ) AS pvt
            JOIN dbo.Company c WITH (NOLOCK) ON c.CompanyId = pvt.CompanyId
            JOIN dbo.Stock cs WITH (NOLOCK) ON cs.StockId = pvt.[1]
            LEFT JOIN dbo.Stock ws WITH (NOLOCK) ON ws.StockId = pvt.[2]
            LEFT JOIN dbo.Stock us WITH (NOLOCK) ON us.StockId = pvt.[3]
            WHERE c.Disabled <> 1 AND cs.EntryId IS NOT NULL AND cs.LatestPrice IS NOT NULL AND cs.ChangePercent IS NOT NULL AND cs.Change IS NOT NULL AND cs.LatestVolume IS NOT NULL AND cs.MarketCap IS NOT NULL 
            --WHERE c.Disabled <> 1 AND c.CompanyStatusId IN (1) AND c.CompletedCommonSymbol IS NULL
			GROUP BY  pvt.CompanyId, cs.ChangePercent , cs.LatestVolume 

			ORDER BY
					--cs.ChangePercent desc
					cs.ChangePercent asc
					--cs.LatestVolume  desc
					
            `, { type: QueryTypes.SELECT });

        return queryResult;
    }

    async GetStockVolumeLeaders() {

        var queryResult = await this.SqlContext.Sequelize.query(
            `   DECLARE @maxCreatedAt datetime, @maxUpdatedTime datetime, @dayDiff int, @minDate datetime, @maxExtendedPriceTime datetime

            SELECT	 @minDate = '1900-01-01'
                    ,@maxCreatedAt = MAX(CreatedAt)
                    ,@maxUpdatedTime = MAX(s.LatestUpdate)
                    ,@dayDiff = DATEDIFF(dd, MAX(s.LatestUpdate), MAX(CreatedAt))
            from dbo.Stock s

            SELECT @dayDiff = CASE WHEN @dayDiff < 0 THEN 0 ELSE @dayDiff END

			--SELECT @maxCreatedAt [maxCreatedAt], @maxUpdatedTime [maxUpdatedTime_LatestUpdate], @dayDiff [dayDiff], @maxExtendedPriceTime [maxExtendedPriceTime]

            SELECT TOP 10 pvt.CompanyId
            FROM (
                SELECT s.CompanyId, s.SecurityTypeId, MAX(StockId) [StockId]
                FROM [dbo].[Stock] s WITH (NOLOCK)
                WHERE CAST(s.CreatedAt AS date) = CAST(@maxUpdatedTime AS date)
                GROUP BY s.CompanyId, s.SecurityTypeId
                --ORDER BY s.CompanyId
            ) AS src
            PIVOT
            (
                max([StockId])
                FOR SecurityTypeId IN ([1], [2], [3])
            ) AS pvt
            JOIN dbo.Company c WITH (NOLOCK) ON c.CompanyId = pvt.CompanyId
            JOIN dbo.Stock cs WITH (NOLOCK) ON cs.StockId = pvt.[1]
            LEFT JOIN dbo.Stock ws WITH (NOLOCK) ON ws.StockId = pvt.[2]
            LEFT JOIN dbo.Stock us WITH (NOLOCK) ON us.StockId = pvt.[3]
            WHERE c.Disabled <> 1 AND cs.EntryId IS NOT NULL AND cs.LatestPrice IS NOT NULL AND cs.ChangePercent IS NOT NULL AND cs.Change IS NOT NULL AND cs.LatestVolume IS NOT NULL AND cs.MarketCap IS NOT NULL 
            --WHERE c.Disabled <> 1 AND c.CompanyStatusId IN (1) AND c.CompletedCommonSymbol IS NULL
			GROUP BY  pvt.CompanyId, cs.ChangePercent , cs.LatestVolume 

			ORDER BY
					--cs.ChangePercent desc
					--cs.ChangePercent asc
					 cs.LatestVolume  desc
					
            `, { type: QueryTypes.SELECT });

        return queryResult;

    }

    async SaveStockMarketInfo(stocks) {
        var result = await this.SqlContext.Stocks.bulkCreate(stocks);

        return result;
    }

    async SaveStockQuoteInfo(quotes) {

        var putRequests = quotes.map(q => {
            return {
                PutRequest: {
                    Item: {
                        symbol: { S: q.Symbol },
                        entryId: { N: q.EntryId.toString() },
                        createdAt: { S: q.CreatedAt },
                        quote: { S: JSON.stringify(q.Quote) },
                        keyStats: { S: JSON.stringify(q.KeyStats) }
                    }
                }
            }
        });

        //get dynamoDB full table name
        var tableName = DynamoContext.GetTableName('iex-quote');
        const params = {
            RequestItems: {
                [`${tableName}`]: putRequests
            },
        };

        /*  dynamoDB only allows saving in chunks of 25 or a total of 16MB */
        var requestChunks = Utility.ChunkInGroups(putRequests, StockDatabaseRepository.BatchWriteMaximumCount);

        try {
            Promise.all(
                requestChunks.map((chunk, index) => {

                    setTimeout(() => {

                        return this.DynamoContext.Quotes.BatchWrite({
                            RequestItems: {
                                [`${tableName}`]: chunk
                            },
                        })

                    }, index + 1 * 300);

                })
            );

        } catch (error) {
            console.log(error);
            throw error;
        }

    }

    /**
     * Returns the dynamodb detail information for the requested stocks.
     * @param stocks List of stock information
     * @param attributeList A comma separated list of attributes. Eg.: Season, Episode, Title, Subtitle
     */
    async GetStockMarketDetailsInfo(stocks, attributeList = null, useCache = true) {

        var ids = stocks.map(s => s.companyId ?? s.CompanyId).sort((a, b) => a - b);
        var tableName = DynamoContext.GetTableName('stock');


        var scanChunks = Utility.ChunkInGroups(ids, 100);

        var stockDetails = await Promise.all(
            await scanChunks.map(async (chunk) => {

                var filter = {};
                chunk.map((id, i) => {
                    filter[`:company${++i}`] = id
                });

                var keys = Object.keys(filter).toString();
                var params = {
                    TableName: tableName,
                    FilterExpression: `companyId IN (${keys})`,
                    ExpressionAttributeValues: filter,                     
                }

                if (attributeList) {
                    params.ProjectionExpression = attributeList;
                }
                
                return await this.DynamoContext.Stocks.Scan(params, useCache);
            })
        );

        return stockDetails.flat();
    }

    // #region CRUD
    /* CRUD operations */

    async Get() {

        var stockInfo = await this.GetStockMarketInfoByCompanyStatus([1, 2]);

        /* FinTrack Curated Data = DynamoDB */
        var stocks = stockInfo.map(i => { return { companyId: i.CompanyId, symbol: i.CommonSymbol } });

        var savedDetails = await this.GetStockMarketDetailsInfo(stocks);

        return savedDetails;


    }

    async Scan(params){

        return await this.DynamoContext.Stocks.ScanX(params);

    }
    async Create(params) {
        return await this.DynamoContext.Stocks.PutItemDocument(params);
    }

    async Read(params) {

        return await this.DynamoContext.Stocks.GetItem(params);
    }

    async Update(params) {

        return await this.DynamoContext.Stocks.UpdateItemDocument(params);
    }

    async Delete(params) {

        return await this.DynamoContext.Stocks.DeleteItem(params);
    }

    // #endregion CRUD
}

module.exports = DataRepository;