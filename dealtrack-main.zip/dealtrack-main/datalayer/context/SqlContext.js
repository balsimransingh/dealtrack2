const moment = require("moment");
const sql = require("mssql");
const config = require("../../config");
const { Sequelize, Model, DataTypes } = require("sequelize");

DataTypes.DATE.prototype._stringify = function _stringify(date, options) {
  return this._applyTimezone(date, options).format("YYYY-MM-DD HH:mm:ss.SSS");
};

class SqlContext {
  static Config = config.MSSQL.StocksConnectionString;

  constructor() {
    this.Sequelize = new Sequelize(
      SqlContext.Config.database,
      SqlContext.Config.user,
      SqlContext.Config.password,
      {
        host: SqlContext.Config.server,
        dialect: "mssql",
        dialectOptions: {
          encrypt: true,
        },
        /* sequelize logging. Remove this to turn on logging */
        logging: false,
      }
    );
  }
}

// export default SqlContext;
module.exports = SqlContext;
