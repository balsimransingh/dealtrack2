const { DynamoDBClient, QueryCommand, GetItemCommand, PutItemCommand, BatchGetItemCommand, BatchWriteItemCommand } = require("@aws-sdk/client-dynamodb");
const DynamoStock = require("../../data/DynamoStock");
const Quote = require("../../data/Quote");

const config = require("../../config");


class DynamoContext {
    static region = config.DynamoDB.AWSConfiguration.region;

    constructor() {
        /*  Create DynamoDB service object */
        this.DynamoClient = new DynamoDBClient({ region: DynamoContext.region });

        this.#ModelDefinition();
    }
    
    
    get Quotes() {
        return Quote;
    }

    get Stocks() {
        return DynamoStock;
    }



    #ModelDefinition() {        

    }

    static GetTableName(tableName)
    {
        return `${config.DynamoDB.AWSConfiguration.prefix}.${tableName}`;
    }
}

module.exports = DynamoContext;