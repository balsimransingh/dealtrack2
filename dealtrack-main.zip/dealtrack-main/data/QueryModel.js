var AWS = require('aws-sdk');
const { DynamoDB, DynamoDBClient, QueryCommand, ScanCommand, GetItemCommand, PutItemCommand, UpdateItemCommand, DeleteItemCommand, BatchGetItemCommand, BatchWriteItemCommand } = require("@aws-sdk/client-dynamodb");
const { marshall, unmarshall } = require("@aws-sdk/util-dynamodb");
const config = require('../config');

class QueryModel {
    static MSSQLConfig = config.MSSQL;

    static DynamoDBConfig = config.DynamoDB;

    static client = this.DynamoClient = new DynamoDBClient({ region: QueryModel.DynamoDBConfig.AWSConfiguration.region });
    static documentClient = new AWS.DynamoDB.DocumentClient({ region: QueryModel.DynamoDBConfig.AWSConfiguration.region });
    static dynamoDB = new AWS.DynamoDB({ region: QueryModel.DynamoDBConfig.AWSConfiguration.region });

    static async init(options) {
        throw new TypeError('This method should be overridden by inheriting classes.');
    }

    static async BatchGetItem(params) {
        var data = [];

        try {
            data = await QueryModel.client.send(new BatchGetItemCommand(params));

            //console.log("Success, items retrieved", data);

        } catch (error) {
            console.log(error);
            throw error;
        }

        return data;
    }

    static async BatchWrite(params) {
        var inserted = false;

        try {
            const data = await QueryModel.client.send(new BatchWriteItemCommand(params));
            inserted = true;

            //console.log("Success, items inserted", data);

        } catch (error) {
            console.log(error);
            throw error;
        }

        return inserted;
    }

    static async PartiQL(statement) {
        var data = []

        try {
            data = await this.dynamoDB.executeStatement({ Statement: statement }).promise();

            if (data != null) {
                data = data.Items.map(i => AWS.DynamoDB.Converter.unmarshall(i));
            }

            //console.log("Success, items queried", data);

        } catch (error) {
            console.log("Error reading bacth to DynamoDB", error);
            throw error;
        }

        return data;
    }

    static async Query(params) {
        var data = [];

        try {
            data = await QueryModel.client.send(new QueryCommand(params));

            if (data != null) {
                data = data.Items.map(i => unmarshall(i));
            }

            //console.log("Success, items queried", data);

        } catch (error) {
            console.log("Error reading bacth to DynamoDB", error);
            throw error;
        }

        return data;
    }

     /**
     * Scan the selected DynamoBD table .
     * @param params The scan parameters.
     * @returns A new the scan data items if a match exists.
     */
      static async ScanX(params) {
        var data = [];

        try {
            data = await QueryModel.client.send(new ScanCommand(params));

            if (data != null) {
                data = data.Items.map(i => unmarshall(i));
            }

            //console.log("Success, items scanned", data);

        } catch (error) {

            console.log("Error scanning data from DynamoDB", error);
            throw error;
        }

        return data;
    }

    static async Scan(params, useCache = true) {
        var result = [];

        if (QueryModel.DynamoDBConfig.AWSConfiguration.dax.enabled == false || useCache == false ) {
            QueryModel.daxClient = null;
        }

        var dbClient = QueryModel.daxClient != null ? QueryModel.daxClient : QueryModel.documentClient;

        try {
            
            do {                
                var data = await dbClient.scan(params).promise();

                if (data) {
                    result = result.concat(data.Items);
                    params.ExclusiveStartKey = data.LastEvaluatedKey;
                }

            } while (typeof data.LastEvaluatedKey !== "undefined");

        } catch (error) {

            console.log("Error scanning data from DynamoDB", error);
            throw error;
        }

        return result;
    }


    /**
     * Get an item from the selected DynamoBD table.
     * @param params The get parameters.
     * @returns A dynamo table item
     **/
    static async GetItem(params) {
        var data = null;

        try {
            data = await QueryModel.client.send(new GetItemCommand(params));

            //console.log("Success, items retrieved", data);

        } catch (error) {
            console.log(error);

            throw error;
        }

        if (!data.Item) {
            return null;
        }

        return unmarshall(data?.Item);
    }

    /**
     * Create an item from the selected DynamoBD table.
     * @param params The get parameters.
     * @returns A dynamo table item
     */
    static async PutItem(params) {
        var data = null;

        try {
            data = await QueryModel.client.send(new PutItemCommand(params));

            //console.log("Success, items retrieved", data);

        } catch (error) {
            console.log(error);

            throw error;
        }

        return data;
    }

    static async PutItemDocument(params) {
        var data = null;

        try {
            data = await QueryModel.documentClient.put(params).promise();

            //console.log("Success, items retrieved", data);

        } catch (error) {
            console.log(error);

            throw error;
        }

        return data;
    }

    /**
     * Update an item from the selected DynamoBD table.
     * @param params The get parameters.
     * @returns A dynamo table item
     */
    static async UpdateItem(params) {
        var data = null;

        try {
            data = await QueryModel.client.send(new UpdateItemCommand(params));

            //console.log("Success, items retrieved", data);

        } catch (error) {
            console.log(error);

            throw error;
        }

        return data;
    }

    static async UpdateItemDocument(params) {
        var data = null;

        try {
            data = await QueryModel.documentClient.update(params).promise();

            //console.log("Success, items retrieved", data);

        } catch (error) {
            console.log(error);

            throw error;
        }

        return data.Attributes;
    }

    /**
     * Delete an item from the selected DynamoBD table.
     * @param params The get parameters.
     * @returns A dynamo table item
     */
    static async DeleteItem(params) {
        var data = null;

        try {
            data = await QueryModel.client.send(new DeleteItemCommand(params));

            //console.log("Success, items retrieved", data);

        } catch (error) {
            console.log(error);

            throw error;
        }

        return data;
    }
}

module.exports = QueryModel;