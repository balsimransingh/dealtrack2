const { DynamoDB, DynamoDBClient, QueryCommand, ScanCommand, GetItemCommand, PutItemCommand, UpdateItemCommand,  DeleteItemCommand, BatchGetItemCommand, BatchWriteItemCommand } = require("@aws-sdk/client-dynamodb");
const { marshall, unmarshall } = require("@aws-sdk/util-dynamodb");
const QueryModel = require('./QueryModel');


class DynamoStock extends QueryModel {

    static client = this.DynamoClient = new DynamoDBClient({ region: QueryModel.DynamoDBConfig.AWSConfiguration.region });

    static async init(options) {

    }
    
}

module.exports = DynamoStock;