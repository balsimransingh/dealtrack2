const { DynamoDBClient, QueryCommand, GetItemCommand, PutItemCommand, BatchGetItemCommand, BatchWriteItemCommand, ScanCommand } = require("@aws-sdk/client-dynamodb");
const QueryModel = require('./QueryModel');

class Quote extends QueryModel {

    static client = this.DynamoClient = new DynamoDBClient({ region: QueryModel.DynamoDBConfig.AWSConfiguration.region });

    static async init(options) {

    }

}

module.exports = Quote;